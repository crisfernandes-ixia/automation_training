from ixnetwork_restpy import *
import time
import traceback
import os
import random

"""
_Load A saved Config file 
- Ports are UN-Mapped 
- Ports Are called Port1 and Port2 
- There is traffic
"""


class testVars: pass


def compare_numbers(num1, num2):
    threshold = 0.98
    difference = abs(num1 - num2)
    avg = (num1 + num2) / 2
    percent_difference = difference / avg

    if percent_difference <= (1 - threshold):
        return True

    return False


def main():
    TestVars = testVars()
    # description
    TestVars.chassisIp: str = '10.80.81.12'
    TestVars.sessionIp: str = 'localhost'
    TestVars.sessionId: str = 1
    TestVars.user: str = 'cris'
    TestVars.cleanConfig: bool = True
    TestVars.password: str = 'Keysight#12345'
    TestVars.txPort: str = '6/1'
    TestVars.rxPort: str = '6/2'
    outLogFile: str = 'loadSession_' + time.strftime("%Y%m%d-%H%M%S") + '.log'
    uniqueName: str = 'addPortst_' + TestVars.user + time.strftime("%Y%m%d-%H%M")
    savedFile: str = '4_LoadSession.ixncfg'

    if TestVars.sessionId == 'None':
        TestVars.sessionId = None

    try:
        session = SessionAssistant(IpAddress=TestVars.sessionIp,
                                   UserName=TestVars.user,
                                   Password=TestVars.password,
                                   SessionId=TestVars.sessionId,
                                   SessionName=uniqueName,
                                   ClearConfig=TestVars.cleanConfig,
                                   LogLevel='info',
                                   LogFilename=outLogFile)


        ixNet = session.Ixnetwork
        ixNet.info(f"Step#1 - Init - Rest Session {session.Session.Id} established.")
        ixNet.info(f'Loading config file: {savedFile}')
        file_path = os.path.join(os.path.abspath(os.path.dirname(__file__)), savedFile)
        file_path_temp = file_path.replace(".ixncfg",  "_" + TestVars.user + '.ixncfg')
        # Loading the original file
        ixNet.LoadConfig(Files(file_path, local_file=True))
        ixNet.info(f"Original File: {file_path} uploaded.")
        ixNet.SaveConfig(Files(file_path_temp, local_file=True))
        ixNet.info(f"Saving as temp since we are making changes: {file_path_temp}")
        # LESS FLEXIBLE BUT FASTER
        vport_dic = dict()

        ### LEARN BIT -- NAME HERE IS VERY IMPORTANT
        port_map = session.PortMapAssistant()
        mySlot, portIndex = TestVars.txPort.split("/")
        vport_dic["Port1"] = port_map.Map(TestVars.chassisIp, mySlot, portIndex, Name="Port1")
        mySlot, portIndex = TestVars.rxPort.split("/")
        vport_dic["Port2"] = port_map.Map(TestVars.chassisIp, mySlot, portIndex, Name="Port2")

        '''
        # if you don't know the port name
        # A list of chassis to use
        ixChassisIpList = ['192.168.70.128']
        portList = [[ixChassisIpList[0], 1, 1], [ixChassisIpList[0], 2, 1]]

        portMap = session.PortMapAssistant()
        vport = dict()
        for index,port in enumerate(portList):
            # For the port name, get the loaded configuration's port name
            portName = ixNetwork.Vport.find()[index].Name
            portMap.Map(IpAddress=port[0], CardId=port[1], PortId=port[2], Name=portName)

        '''
        '''
        Map a test port to a virtual port

        Examples
        --------
            Map(IpAddress='10.36.74.26', CardId=2, PortId=13, Name='Tx')
            Map(Name='Tx', Port=('10.36.74.26', 2, 13))
            Map('10.36.74.26', 2, 13, Name='Tx')
            Map('10.36.74.26', 2, 14, Name=vport.Name)
            Map(Location='10.36.74.26;1;1', Name='Tx')
            Map(Location='localuhd/1', Name='Tx')

        Args
        ----
        - IpAddress (str): The ip address of the platform that hosts the card/port combination.
            If the IpAddress is not specified the default value is 127.0.0.1
        - CardId (number): The id of the card that hosts the port
            If the CardId is not specified the default value is 1
        - PortId (number): The id of the port.
        - Name (str): The name of a virtual port.
            If the Name is not specified a default named virtual port will be created.
            If the Name is specified an attempt to find it will be made.
            If it does not exist a virtual port with that name will be created.
            The found or created vport will then be mapped.
        - Port (tuple(IpAddress,CardId,PortId)): A test port location tuple consisting of an IpAddress, CardId, PortId.
            Use this parameter instead of specifying the individual IpAddress, CardId, PortId parameters.
            If this parameter is not None it will override any IpAddress, CardId, PortId parameter values.
        - Location (str): A test port location using the new 9.10 location syntax
            The location syntax for test ports can be discovered by using the /locations API
            If this parameter is not None it will override any IpAddress, CardId, PortId, Port parameter values

        Returns
        -------
        - obj(ixnetwork_restpy.testplatform.sessions.ixnetwork.vport.vport.Vport): A Vport object

        Raises
        ------
        - ValueError: a PortId was not provided
        - RuntimeError: Location API is not supported on the server
        - ServerError: an unexpected error occurred on the server
        """

        
        '''



        ### FORCEOWNERSHIP
        port_map.Connect()

        portStats = StatViewAssistant(ixNet, 'Port Statistics')
        portStats.CheckCondition('Link State', StatViewAssistant.REGEX, 'Link\s+Up', Timeout=20, RaiseException=False)

        ## Start Protocols
        ixNet.StartAllProtocols(Arg1='sync')

        ixNet.info('Verify protocol sessions\n')
        protocolSummary = session.StatViewAssistant('Protocols Summary')
        protocolSummary.CheckCondition('Sessions Not Started', protocolSummary.EQUAL, 0)
        ixNet.info(protocolSummary)

        ## FIND Traffic Items
        findSpecifcTrafficItem = ixNet.Traffic.TrafficItem.find(Name='Traffic Item 1')
        configElement = findSpecifcTrafficItem.ConfigElement.find()[0]
        configElement.FrameRate.update(Rate=50)
        configElement.TransmissionControl.update(Type = 'continuous')
        # GENERATE IF YOU MAKE CHANGES TO TRAFFIC ITEM
        findSpecifcTrafficItem.Generate()
        # Apply and Start
        ixNet.Traffic.Apply()
        time.sleep(10)
        ## The only 2 things that you can change while the traffic is running
        dynamicFramSize = ixNet.Traffic.DynamicFrameSize.find()[0]
        dynamicRate = ixNet.Traffic.DynamicRate.find()[0]

        # Traffic is Running ....
        ixNet.Traffic.Start()
        time.sleep(30)

        # Let's change the RATE to 75%
        dynamicRate.update(Rate = 75)

        # Let's Change the Size to Random
        someRandSize = int(round(random.uniform(128, 1492), 0))
        dynamicFramSize.update(FixedSize=someRandSize)

        # Stop Traffic 
        ixNet.Traffic.Stop()

        # Check Traffic State
        while True:
            if ixNet.Traffic.State == 'stopped':
                break
            ixNet.info(f"Traffic State {ixNet.Traffic.State}")
            time.sleep(2)

        # Get Stats
        trafficItemStatistics = session.StatViewAssistant('Traffic Item Statistics')
        trafficItemStatistics.AddRowFilter('Traffic Item', trafficItemStatistics.REGEX, '^Traffic Item 1$')
        txFrames = float(trafficItemStatistics.Rows['Tx Frames'])
        rxFrames = float(trafficItemStatistics.Rows['Rx Frames'])
        ixNet.info(f"Tx frames {txFrames} should be equal to rx frames {rxFrames}")
        if compare_numbers(txFrames,rxFrames):
            ixNet.info("Test PASS")
        else:
            ixNet.info("Test FAILED")

        # Stopping Protocols
        ixNet.StopAllProtocols()
        time.sleep(10)

        # Release all ports
        ixNet.Vport.find().ReleasePort()

        if TestVars.sessionId == None:
            ixNet.info(f"Removing Session we created...bye")
            session.Session.remove()
        else:
            ixNet.info(f"Cleaning up session and leaving it up...bye")
            ixNet.NewConfig()

    except Exception as errMsg:
        print('\n%s' % traceback.format_exc())

if __name__ == "__main__":
    main()

