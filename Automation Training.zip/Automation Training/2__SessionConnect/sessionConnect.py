from ixnetwork_restpy import *
import time
import traceback

"""Create a session or connect to an existing session.
Provides access to the TestPlatform, Sessions, Ixnetwork, PortMapAssistant and StatViewAssistant classes.

Description
-----------
- If SessionId is None and SessionName is None a new session will be created.
- If SessionId is not None then an attempt will be made to connect to a session with that id.
- If SessionId is None and SessionName is not None then an attempt will be to connect to a session with that name.
- If Sessionid is not None and SessionName is not None then an attempt will be made to connect to a session with that id and if successful the session will be renamed to SessionName
- Set the LogLevel parameter to LOGLEVEL_INFO for more information on the connection attempts to the TestPlatform.

Args
----
- IpAddress (str): The ip address of the TestPlatform to connect to where test sessions will be created or connected to.
- RestPort (int): The rest port of the TestPlatform to connect to.
- UserName (str): The username to be used for authentication
- Password (str): The password to be used for authentication
- ApiKey (str): The api key to be used for authentication. If set the ApiKey will override the UserName and Password
- IgnoreEnvProxy (bool): Ignore the environment proxy bypass settings.
- VerifyCertificates (bool): Verify the certificate
- LogFilename (str): The name of the logger log filename.
- LogLevel (str(LOGLEVEL_NONE|LOGLEVEL_INFO)): The logger log level that will be set.
- SessionId (int): The id of the session to connect to.
- SessionName (str): The name of the session to connect to.
- ApplicationType (str(APP_TYPE_IXNETWORK|APP_TYPE_QUICKTEST)): The type of IxNetwork middleware test session to create
- ClearConfig (bool): Clear the current configuration

Raises
------
- ConnectionError: If the TestPlatform cannot be reached.
- UnauthorizedError: Authentication failed, access is unauthorized
- NotFoundError: The SessionId was not found on the test platform
- ValueError: If the version of IxNetwork server is not supported. The minimum version supported is 8.42.
"""
class testVars: pass

def main():
    TestVars = testVars()
    # description
    TestVars.chassisIp : str = '10.80.81.12'
    TestVars.sessionIp : str = 'localhost'
    TestVars.sessionId : str = 1
    TestVars.user : str      = 'cris'
    TestVars.cleanConfig : bool = True
    TestVars.password: str   =  'Keysight#12345'
    outLogFile : str = 'sessionConnect_' + time.strftime("%Y%m%d-%H%M%S") + '.log'
    uniqueName : str = 'sessionConnect_' + TestVars.user + time.strftime("%Y%m%d-%H%M")

    if TestVars.sessionId == 'None':
        TestVars.sessionId = None

    try:
        session = SessionAssistant(IpAddress=TestVars.sessionIp,
                                   UserName=TestVars.user,
                                   Password=TestVars.password,
                                   SessionId=TestVars.sessionId,
                                   SessionName=uniqueName,
                                   ClearConfig=TestVars.cleanConfig,
                                   LogLevel='info',
                                   LogFilename=outLogFile)

        ixNet = session.Ixnetwork
        ixNet.info(f"Step#1 - Init - Rest Session {session.Session.Id} established.")

        if TestVars.sessionId == None:
            ixNet.info(f"Removing Session we created...bye")
            session.Session.remove()
        else:
            ixNet.info(f"Cleaning up session and leaving it up...bye")
            ixNet.NewConfig()

    except Exception:
        traceback.print_exc()

if __name__ == "__main__":
    main()

