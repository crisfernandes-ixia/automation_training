from ixnetwork_restpy import *
import time
import traceback
import os
from tabulate import tabulate

"""
"""
class testVars: pass

def compare_numbers(num1, num2, threshold : float = 0.98) -> bool :
    difference = abs(num1 - num2)
    avg = (num1 + num2) / 2
    percent_difference = difference / avg
    if percent_difference <= (1 - threshold):
        return True
    return False

def main():
    TestVars = testVars()
    # description
    TestVars.chassisIp: str = '10.80.81.12'
    TestVars.sessionIp: str = 'localhost'
    TestVars.sessionId: str = 1
    TestVars.user: str = 'cris'
    TestVars.restport :int = 1109
    TestVars.cleanConfig: bool = True
    TestVars.password: str = 'pass123'
    TestVars.txPort: str = '1/1'
    TestVars.rxPort: str = '1/2'
    TestVars.routesToExport: int = 10000
    outLogFile: str = 'fromScratch_' + time.strftime("%Y%m%d-%H%M%S") + '.log'
    uniqueName: str = 'mySession_' + TestVars.user + time.strftime("%Y%m%d-%H%M")

    vport_dic = dict()

    if TestVars.sessionId == 'None':
        TestVars.sessionId = None

    try:
        session = SessionAssistant(IpAddress=TestVars.sessionIp,
                                   UserName=TestVars.user,
                                   Password=TestVars.password,
                                   RestPort=TestVars.restport,
                                   SessionId=TestVars.sessionId,
                                   SessionName=uniqueName,
                                   ClearConfig=TestVars.cleanConfig,
                                   LogLevel='info',
                                   LogFilename=outLogFile)


        ixNet = session.Ixnetwork
        ixNet.info(f"Step#1 - Init - Rest Session {session.Session.Id} established.")

    except Exception as errMsg:
        print('\n%s' % traceback.format_exc())

    # Map(Location='10.36.74.26;1;1', Name='Tx')
    port_map = session.PortMapAssistant()
    mySlot, portIndex = TestVars.txPort.split("/")
    my_location = TestVars.chassisIp + ";" + mySlot + ";" + portIndex
    vport_dic["Port1"] = port_map.Map(Location =  my_location, Name="Port1")
    mySlot, portIndex = TestVars.rxPort.split("/")
    my_location = TestVars.chassisIp + ";" + mySlot + ";" + portIndex
    vport_dic["Port2"] = port_map.Map(Location = my_location , Name="Port2")
    try:
        port_map.Connect()
    except Exception:
        traceback.print_exc()

    portStats = StatViewAssistant(ixNet, 'Port Statistics')
    portStats.CheckCondition('Link State', StatViewAssistant.REGEX, 'Link\s+Up')

    ixNet.info('Creating Topology Group 1')
    topology1 = ixNet.Topology.add(Name='Topo1', Ports=vport_dic['Port1'])
    deviceGroup1 = topology1.DeviceGroup.add(Name='DG1', Multiplier='2')
    ethernet1 = deviceGroup1.Ethernet.add(Name='Eth1')
    ethernet1.Mac.Increment(start_value='00:CA:FF:EE:00:01', step_value='00:00:00:00:00:01')
    ethernet1.EnableVlans.Single(True)

    ixNet.info('Configuring vlanID')
    vlanObj = ethernet1.Vlan.find()[0].VlanId.Increment(start_value=100, step_value=0)

    ixNet.info('Configuring IPv4')
    ipv4 = ethernet1.Ipv4.add(Name='Ipv4')
    ipv4.Address.Increment(start_value='172.16.1.1', step_value='0.0.0.1')
    ipv4.GatewayIp.Increment(start_value='172.16.2.1', step_value='0.0.0.1')

    ixNet.info('Configuring BgpIpv4Peer 1')
    bgp1 = ipv4.BgpIpv4Peer.add(Name='Bgp1')
    bgp1.DutIp.Increment(start_value='172.16.2.1', step_value='0.0.0.1')
    # SINGLE = GLOBAL
    bgp1.Type.Single('external')
    # VALUELIST = INDIVIDUAL
    #bgp1.Type.ValueList(['external','internal','internal'])
    bgp1.LocalAs2Bytes.Increment(start_value=65535, step_value=0)
    ixNet.info('Configuring Network Group 1')
    networkGroup1 = deviceGroup1.NetworkGroup.add(Name='BGP-Routes1', Multiplier='10')
    ipv4PrefixPool = networkGroup1.Ipv4PrefixPools.add(NumberOfAddresses='1')
    ipv4PrefixPool.Connector.find().update(ConnectedTo=bgp1)
    ipv4PrefixPool.NetworkAddress.Increment(start_value='182.16.1.1', step_value='0.0.0.1')
    ipv4PrefixPool.PrefixLength.Single(32)
    
    ixNet.info('Creating Topology Group 2')
    topology2 = ixNet.Topology.add(Name='Topo2', Ports=vport_dic['Port2'])
    deviceGroup2 = topology2.DeviceGroup.add(Name='DG2', Multiplier='2')
    ethernet2 = deviceGroup2.Ethernet.add(Name='Eth2')
    ethernet2.Mac.Increment(start_value='00:BA:DB:EE:F0:01', step_value='00:00:00:00:00:01')
    ethernet2.EnableVlans.Single(True)
    ixNet.info('Configuring vlanID')
    ethernet2.Vlan.find()[0].VlanId.Single(100)
    ixNet.info('Configuring IPv4')
    ipv4_2 = ethernet2.Ipv4.add(Name='Ipv4')
    ipv4_2.Address.Increment(start_value='172.16.2.1', step_value='0.0.0.1')
    ipv4_2.GatewayIp.Increment(start_value='172.16.1.1', step_value='0.0.0.1')

    ixNet.info('Configuring BgpIpv4Peer 2')
    bgp2 = ipv4_2.BgpIpv4Peer.add(Name='Bgp2')
    bgp2.DutIp.Increment(start_value='172.16.1.1', step_value='0.0.0.1')
    # SINGLE = GLOBAL
    bgp2.Type.Single('external')
    # VALUELIST = INDIVIDUAL
    #bgp1.Type.ValueList(['external','internal','internal'])
    bgp2.LocalAs2Bytes.Increment(start_value=65545, step_value=0)
    bgp2.FilterIpV4Unicast.Single(True)
    pool2 = deviceGroup2.NetworkGroup.add(Name='Internet Routes')
    ixNet.info(f'Setup Phase - Adding a Ipv4 Pool of addresses')
    importParams = pool2.Ipv4PrefixPools.add()
    ixNet.info(f'Setup Phase - Connecting the Ipv4 pool to be advertised by the eBGP')
    importParams.Connector.find().update(ConnectedTo=bgp2)
    ####
    ixNet.info(f'Setup Phase - Updating import params for the routes including how many, file and type')
    importParams.BgpIPRouteProperty.find().ImportBgpRoutesParams.update(RouteLimit=TestVars.routesToExport)
    bgp_table_filename = os.path.join(os.path.dirname(__file__), 'bgptable.txt')
    importParams.BgpIPRouteProperty.find().ImportBgpRoutesParams.update(DataFile = Files(bgp_table_filename), FileType = 'cisco')
    ixNet.info(f'Setup Phase - Importing routes from file {bgp_table_filename}')
    start_time = time.time()
    importParams.BgpIPRouteProperty.find().ImportBgpRoutesParams.ImportBgpRoutes()
    ixNet.info(f"Setup Phase - It took {time.time() - start_time:.2f} seconds to import {TestVars.routesToExport} routes from file.")
    ixNet.info(f'Setup Phase - Enabling Large Communities for all {TestVars.routesToExport} routes')
    ####
    importParams.BgpIPRouteProperty.find().EnableLargeCommunities.Single(True)
    lgCommunity = importParams.BgpIPRouteProperty.find().BgpNonVPNRRLargeCommunitiesList.find().LargeCommunity
    ixNet.info(f'Setup Phase - Setting up unique communities for each route using strings')
    lgCommunity.String(string_pattern='65550:{Inc:1,1}:10')

    ixNet.info(f'Test Phase - Step 1: Staring Protocols - Control Plane messages')
    ixNet.StartAllProtocols(Arg1='sync')
    ixNet.info(f'Test Phase - Step 2: Verify eBGP session is UP -- Default is 90 seconds')
    protocolsSummary = StatViewAssistant(ixNet, 'Protocols Summary')
    protocolsSummary.AddRowFilter('Protocol Type', StatViewAssistant.REGEX, '(?i)^BGP?')
    protocolsSummary.CheckCondition('Sessions Down', StatViewAssistant.EQUAL, 0)
    protocolsSummary.CheckCondition('Sessions Not Started', StatViewAssistant.EQUAL, 0)

    bgpPerPortTable = StatViewAssistant(ixNet, 'BGP Peer Per Port')
    bgpPerPortTable.AddRowFilter('Port', StatViewAssistant.REGEX, 'Port1')
    bgpPerPortTable.CheckCondition('Routes Rx', StatViewAssistant.EQUAL, TestVars.routesToExport, Timeout=30, RaiseException=False)

    ixNet.info(f'Test Phase - Step 4: Demo how to get information learned on BGP peer')
    index = ipv4_2.get_device_ids(Address='172.16.2.1')
    bgp2.GetIPv4LearnedInfo(index)
    for y in bgp2.LearnedInfo.find():
        print(tabulate(y.Values,headers=y.Columns))

    ixNet.info('Test Phase - Step 4: Create Unidirectional Traffic Item - Imported Routes  to eBgp1 routes')
    traffCe1ToCe2 = ixNet.Traffic.TrafficItem.add(Name='From Bgp2 Routes', BiDirectional=False,TrafficType='ipv4')
    traffCe1ToCe2.EndpointSet.add(Sources=pool2, Destinations=ipv4PrefixPool)
    configElement = traffCe1ToCe2.ConfigElement.find()[0]
    ixNet.info('Test Phase - Step 4.1: Setting Traffic item to send 100% line rate and 1280 byte pkt')
    configElement.FrameRate.update(Type='percentLineRate', Rate=100)
    configElement.FrameSize.FixedSize = 1280
    ixNet.info('Test Phase - Step 4.2: Enabling Traffic Item flow tracking')
    traffCe1ToCe2.Tracking.find()[0].TrackBy = ['trafficGroupId0']
    ixNet.info('Test Phase - Step 4.3: Creating, Applying and Staring traffic.')
    traffCe1ToCe2.Generate()
    ixNet.Traffic.Apply()
    ixNet.Traffic.Start()

    ixNet.info('Test Phase - Step 5: Let traffic run for 20 seconds')
    time.sleep(20)

    ixNet.info('Test Phase - Step 6: Collecting traffic item statistics and printing L1 Rate stats')
    flowStatistics = session.StatViewAssistant('Traffic Item Statistics')
    for rowNumber, flowStat in enumerate(flowStatistics.Rows):
        ixNet.info(f"Test Phase - Step 7: Traffic Item:{flowStat['Traffic Item']} TX L1 Rate:{float(flowStat['Tx L1 Rate (bps)']):,} RX L1 Rate:{float(flowStat['Rx L1 Rate (bps)']):,}\n")
        time.sleep(10)

    # Stop Traffic 
    ixNet.Traffic.Stop()

    # Check Traffic State
    while True:
        if ixNet.Traffic.State == 'stopped':
            break
        ixNet.info(f"Traffic State {ixNet.Traffic.State}")
        time.sleep(2)

    # Get Stats
    trafficItemStatistics = session.StatViewAssistant('Traffic Item Statistics')
    txFrames = float(trafficItemStatistics.Rows['Tx Frames'])
    rxFrames = float(trafficItemStatistics.Rows['Rx Frames'])
    ixNet.info(f"Tx frames {txFrames} should be equal to rx frames {rxFrames}")
    if compare_numbers(txFrames,rxFrames,0.99):
        ixNet.info("Test PASS")
    else:
        ixNet.info("Test FAILED")

    # Stopping Protocols
    ixNet.StopAllProtocols()
    time.sleep(10)

    # Release all ports
    ixNet.Vport.find().ReleasePort()

    if TestVars.sessionId == None:
        ixNet.info(f"Removing Session we created...bye")
        session.Session.remove()
    else:
        ixNet.info(f"Cleaning up session and leaving it up...bye")
        ixNet.NewConfig()

if __name__ == "__main__":
    main()
