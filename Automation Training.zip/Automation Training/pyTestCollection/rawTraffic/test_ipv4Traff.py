from ixnetwork_restpy import *
import time
import sys, json, re, pdb
import myLib

def test_main():
    TestVars = myLib.testVars()
    TestVars.chassisIp: str = '10.80.81.12'
    TestVars.sessionIp: str = 'localhost'
    TestVars.sessionId: str = '1'
    TestVars.Port1: str = '1/1'
    TestVars.Port2: str = '1/2'
    TestVars.cleanConfig: bool = True
    TestVars.takePorts: bool = True
    TestVars.user: str = 'admin'
    TestVars.password: str = 'Keysight#12345'
    TestVars.pktSize: int = 512

    #Local
    uniqueName: str = 'rawTraffic_' + TestVars.user + time.strftime("%Y%m%d-%H%M")
    outLogFile: str = 'rawTraffic_' + time.strftime("%Y%m%d-%H%M%S") + '.log'

    session = SessionAssistant(IpAddress=TestVars.sessionIp,
                                   UserName=TestVars.user,
                                   Password=TestVars.password,
                                   SessionId=TestVars.sessionId,
                                   SessionName=uniqueName,
                                   ClearConfig=TestVars.cleanConfig,
                                   LogLevel='info',
                                   LogFilename=outLogFile)

    ixNet = session.Ixnetwork
    assert int(session.Session.Id) > 0, f"Unable to establish session with {TestVars.sessionIp}"
    ixNet.info(f"Step#1 - Config - Rest Session {session.Session.Id} established.")
    port_map = session.PortMapAssistant()
    mySlot, portIndex = TestVars.Port1.split("/")
    port_map.Map(TestVars.chassisIp, mySlot, portIndex, Name="Port1")
    mySlot, portIndex = TestVars.Port2.split("/")
    port_map.Map(TestVars.chassisIp, mySlot, portIndex, Name="Port2")

    assert myLib._myConnect(ixNet, port_map), "Unable to get ports up"
    ixNet.info(f"Step#2 - Config - Ports are Up.")

    ixNet.info(f"Step#3 - Config - Setting up port1 Ipv4 stack - 176.16.0.1/16")
    topo1 = ixNet.Topology.add(Name='P1 Topo', Ports= [ixNet.Vport.find(Name="Port1")])
    dev1 = topo1.DeviceGroup.add(Name='Grp 1', Multiplier='500')
    eth1 = dev1.Ethernet.add(Name='P1 Ether')
    eth1.Mac.Increment(start_value='00:01:c0:ff:ee:01', step_value='00:00:00:00:00:01')
    ip1 = eth1.Ipv4.add(Name='P1 Ipv4')
    ip1.Address.Increment(start_value="172.16.0.1", step_value="0.0.0.1")
    ip1.GatewayIp.Increment(start_value="172.16.100.1", step_value="0.0.0.1")
    ip1.Prefix.Single(16)
    ip1.ResolveGateway.Single(value=True)

    ixNet.info(f"Step#4 - Config - Setting up port2 Ipv4 stack - 176.16.100.1/16")
    topo2 = ixNet.Topology.add(Name='P2 Topo', Ports=[ixNet.Vport.find(Name="Port2")])
    dev2 = topo2.DeviceGroup.add(Name='Grp 2', Multiplier='500')
    eth2 = dev2.Ethernet.add(Name='P2 Ether')
    eth2.Mac.Increment(start_value='00:01:ba:db:ad:01', step_value='00:00:00:00:00:01')
    ip2 = eth2.Ipv4.add(Name='P2 Ipv4')
    ip2.Address.Increment(start_value="172.16.100.1", step_value="0.0.0.1")
    ip2.GatewayIp.Increment(start_value="172.16.0.1", step_value="0.0.0.1")
    ip2.Prefix.Single(16)
    ip2.ResolveGateway.Single(value=True)

    ixNet.StartAllProtocols(Arg1='sync')
    ixNet.info(f"Step#8 - Init - Staring all protocols")
    protocolsSummary = StatViewAssistant(ixNet, 'Protocols Summary')
    assert protocolsSummary.CheckCondition('Sessions Up', StatViewAssistant.EQUAL, 1000)

    assert  myLib._myCreateRawFlow(ixNet, "Port1", "Port2")

    ixNet.Traffic.Start()
    traffItemStats = StatViewAssistant(ixNet, 'Traffic Item Statistics')
    assert traffItemStats.CheckCondition('Tx Frames', StatViewAssistant.EQUAL, 5000, Timeout=30, RaiseException=False)
    assert traffItemStats.CheckCondition('Rx Frames', StatViewAssistant.EQUAL, 5000, Timeout=30, RaiseException=False)

    if TestVars.sessionId == None:
        ixNet.info(f"Removing Session we created...bye")
        session.Session.remove()
    else:
        ixNet.info(f"Cleaning up session and leaving it up...bye")
        ixNet.NewConfig()







