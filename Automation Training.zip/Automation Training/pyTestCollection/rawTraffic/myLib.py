import time
from ixnetwork_restpy import *

class testVars: pass


def _myRun(ixNet, logStatus: bool = True):
    """Take in IxNework session and waits for traffic to be in running state"""
    preventInfLoop = 30
    ixNet.Traffic.Start()
    trafficNotRunnning = True
    while trafficNotRunnning:
        currentTrafficState = ixNet.Traffic.State
        if logStatus:
            ixNet.info('Currently traffic is in ' + currentTrafficState + ' state')
        if currentTrafficState == 'started':
            trafficNotRunnning = False
        time.sleep(2)
        preventInfLoop -= 2
        if preventInfLoop < 1:
            return False
    return True

def _myConnect(ixNet, port_map, take_ports = True):
    port_map.Connect(ForceOwnership=take_ports, IgnoreLinkUp=True)
    portStats = StatViewAssistant(ixNet, 'Port Statistics')
    boolPortsAreUp = portStats.CheckCondition('Link State', StatViewAssistant.REGEX, 'Link\s+Up', Timeout=20,
                                              RaiseException=False)
    if boolPortsAreUp:
        return True
    else:
        for vport in ixNet.Vport.find():
            portType = vport.Type[0].upper() + vport.Type[1:]
            portObj = getattr(vport.L1Config, portType)
            if portObj.Media and portObj.Media == 'fiber':
                portObj.Media = 'copper'
            else:
                portObj.Media = 'fiber'

    boolPortsAreUp = portStats.CheckCondition('Link State', StatViewAssistant.REGEX, 'Link\s+Up', Timeout=20,
                                              RaiseException=False)
    return boolPortsAreUp

'''
Helper Function that will 
1. create a raw traffic item and assign single port as source and destination
2. set traffic item rate as percentage of line rate
3. set traffic item packet as fixed size 
4. add Ipv4 + Udp headers to the stack
5. add flow tracking by Traffic Item and Udp src and destination ports 
6. generate traffic item  
'''
def _myCreateRawFlow(ixNet, srcPortName : str, dstPortName : str) :

    name = "From__" + srcPortName + "_to_" + dstPortName + "_Raw"
    rawTrafficItemObj = ixNet.Traffic.TrafficItem.add(Name=name, BiDirectional=False, TrafficType='raw')
    srcVPortProtocols = ixNet.Vport.find(Name=srcPortName).Protocols.find()
    dstVPortProtocols = ixNet.Vport.find(Name=dstPortName).Protocols.find()
    rawTrafficItemObj.EndpointSet.add(Sources=srcVPortProtocols,Destinations=dstVPortProtocols)
    rawTrafficItemObj.update(Name=name)
    configElement = rawTrafficItemObj.ConfigElement.find()[0]
    configElement.FrameRate.update(Type='percentLineRate', Rate=1)
    configElement.FrameSize.FixedSize = 512
    configElement.TransmissionControl.update(Type='fixedFrameCount')
    configElement.TransmissionControl.FrameCount = 5000

    # The Ethernet packet header doesn't need to be created.
    # It is there by default. Just do a find for the Ethernet stack object.
    ethernetStackObj = ixNet.Traffic.TrafficItem.find(Name=name).ConfigElement.find()[0].Stack.find(StackTypeId='ethernet$')
    # NOTE: If you are using virtual ports (IxVM), you must use the Destination MAC address of
    #       the IxVM port from your virtual host (ESX-i host or KVM)
    ixNet.info('Configuring Ethernet packet header')
    ethernetDstField = ethernetStackObj.Field.find(DisplayName='Destination MAC Address')
    ethernetDstField.ValueType = 'increment'
    ethernetDstField.StartValue = "00:aa:bb:cc:00:00"
    ethernetDstField.StepValue = "00:00:00:00:00:01"
    ethernetDstField.CountValue = 500
    ethernetSrcField = ethernetStackObj.Field.find(DisplayName='Source MAC Address')
    ethernetSrcField.ValueType = 'increment'
    ethernetSrcField.StartValue = "00:ba:dd:ad:00:00"
    ethernetSrcField.StepValue = "00:00:00:00:00:01"
    ethernetSrcField.CountValue = 500

    ipv4Template = ixNet.Traffic.ProtocolTemplate.find(TemplateName='ipv4-template.xml')
    ethernetStackObj.Append(Arg2=ipv4Template)
    ipv4Stack = ixNet.Traffic.TrafficItem.find(Name=name).ConfigElement.find()[0].Stack.find(StackTypeId='ipv4')
    ipv4SrcField = ipv4Stack.Field.find(DisplayName='Source Address')
    ipv4SrcField.ValueType = 'increment'
    ipv4SrcField.StartValue = '199.1.1.1'
    ipv4SrcField.StepValue = "0.0.0.1"
    ipv4SrcField.CountValue = 500
    ipv4DstField = ipv4Stack.Field.find(DisplayName='Destination Address')
    ipv4DstField.ValueType = 'increment'
    ipv4DstField.StartValue = "209.0.0.1"
    ipv4DstField.StepValue = "0.0.0.1"
    ipv4DstField.CountValue = 500

    udpTemplate = ixNet.Traffic.ProtocolTemplate.find(TemplateName='udp-template.xml')
    ipv4Stack.Append(Arg2=udpTemplate)
    udpObj =  ixNet.Traffic.TrafficItem.find(Name=name).ConfigElement.find()[0].Stack.find(StackTypeId='udp')
    udpSrcField = udpObj.Field.find(DisplayName='UDP-Source-Port')
    udpSrcField.Auto = False
    udpSrcField.ValueType = 'random'
    rawTrafficItemObj.Tracking.find()[0].TrackBy = ["trackingenabled0", "ipv4DestIp0"]
    rawTrafficItemObj.Generate()
    ixNet.Traffic.Apply()
    return rawTrafficItemObj

def _myCreateIpv4Flow(ixNet, srcPortName : str, dstPortName : str) :
    name = "From__" + srcPortName + "_to_" + dstPortName + "_Ipv4"
    rawTrafficItemObj = ixNet.Traffic.TrafficItem.add(Name=name, BiDirectional=False, TrafficType='ipv4')
    srcVPortProtocols = ixNet.Vport.find(Name=srcPortName).Protocols.find()
    dstVPortProtocols = ixNet.Vport.find(Name=dstPortName).Protocols.find()
    rawTrafficItemObj.EndpointSet.add(Sources=srcVPortProtocols,Destinations=dstVPortProtocols)
    rawTrafficItemObj.update(Name=name)
    configElement = rawTrafficItemObj.ConfigElement.find()[0]
    configElement.FrameRate.update(Type='percentLineRate', Rate=1)
    configElement.FrameSize.FixedSize = 512
    configElement.TransmissionControl.update(Type='fixedFrameCount')
    configElement.TransmissionControl.FrameCount = 5000
    udpTemplate = ixNet.Traffic.ProtocolTemplate.find(TemplateName='udp-template.xml')
    ipv4Stack = ixNet.Traffic.TrafficItem.find(Name=name).ConfigElement.find()[0].Stack.find(StackTypeId='ipv4')
    ipv4Stack.Append(Arg2=udpTemplate)
    udpObj =  ixNet.Traffic.TrafficItem.find(Name=name).ConfigElement.find()[0].Stack.find(StackTypeId='udp')
    udpSrcField = udpObj.Field.find(DisplayName='UDP-Source-Port')
    udpSrcField.Auto = False
    udpSrcField.ValueType = 'random'
    rawTrafficItemObj.Tracking.find()[0].TrackBy = ["trackingenabled0", "ipv4DestIp0"]
    rawTrafficItemObj.Generate()
    ixNet.Traffic.Apply()
    return rawTrafficItemObj
