"""runAndVerify.py
Description:
   Sample script to show BPS RESTv2 common use case. This script can run a test(s) in series and based on the report
   verify pass or failed given a series of user defined checks.

What this script does for every test:
Init Phase:
   - Reads in a special formatted input file.
        - It defaults to testInfo.txt if none is passed in
   - Login to BPS box
   - If <Import Test: True> Import a test
   - Search into the database after it
   - Load the test and check the name
   - If <Import Neighborhood: True>  Import a network config
   - Search for it into the database
   - Load the network neighborhood config
   - Save a new network config as <Network Neighborhood>_runAndVerifyVersion
   - Save the test model as a new test as <Test>_runAndVerifyVersion
   - Reserve ports
Test Phase:
   - Run test until completion giving summary stats every 30 seconds
   - Verify test completion is incrementing
   - Wait for report generation
   - Verify and print all check(s)  -- Pass test criteria
Clean-Up Phase:
   - Un-reserve ports
   - Logout.

Requirements:
   - Python 3 installed
   - Modules: time, sys, json, re, statistics, numpy
   - bps_restpy
   - BPS minimum version 9.0
   - Test and Network Neighborhood file should be in the same directory as script ( if importing files )
   - Text editor for the input file

How to run:
   - The user should be able to run the code after modifying the input ( sample below )
# testInfo.txt
Chassis Ip: 10.80.81.16                         # BPS Ip address
User: admin                                     # BPS User
Password: admin                                 # BPS Password
SleepBetweenTest: 30                            # How long to wait between tests in secs

Test: cf_max_v1                                 # Test to run
Import Test: True                               # Is test on the box already ( False ) or import from local dir ( True )
Network Neighborhood: cf-switch-jumbo           # Network Neighborhood to use
Import Neighborhood: True                       # Is Net Neighborhood present on BPS ( False ) or import from local dir ( True )
Slot Number: 1                                  # Card slot number
Port List: [0, 1]                               # Port List
## Pass test criteria
# Especial check variables - They must be unique CheckX, CheckY, CheckZ
# CheckX: [<Report Section Id>, <Column Name> , <what to do with values>, <operator>, <pass criteria>
# or
# CheckX: ['<Application Protocol>.<Table>', <Column Name> , <what to do with values>, <operator>, <pass criteria>]
# Examples
Check1: ['7.17.15.1','Receive Rate','average','>=','7.5']
Check2: ['Google Quic Version 46.Flows','concurrentAppFlows','average','>=','28']
Check3: ['7.17.15.1','Receive Rate','min','>','5']
Check4: ['7.17.15.1','Receive Rate','max','<','9']
Check5: ['7.23.1.1','Matching Count','match.match1','>=','73'] -- NOT TESTED

Notes:
only average was implemented here
Avg using a normal distribution (+/- 2 std ) - outlier points are ignored
For a test to pass ALL checks MUST be true
"""

# Import BPSv2 python library from outside the folder with samples.
import time, sys, json, re, statistics, numpy, ast
from bps_restpy.bps import BPS,pp

def main():
    testInfo = {}
    globalVars = {}

    inputFile = 'testInfo.txt' if len(sys.argv) == 1 else sys.argv[1]

    with open(inputFile) as f:
        test = testId = None
        for currLine in f:
            if len(currLine.strip()) == 0:
                continue
            if currLine.startswith("## TEST"):
                Null,test,testId = currLine.split()
                testInfo[test+testId] = {}
                testInfo[test + testId]['status'] = 'did not run'
                testInfo[test + testId]['msg'] = None
                continue
            if currLine.startswith("##"):
                continue
            key,value = currLine.split(':')
            if test:
                testInfo[test+testId][key.strip()] = value.strip()
            else:
                globalVars[key.strip()] = value.strip()

    for currTest in testInfo:
        runTest(globalVars,testInfo[currTest],currTest)
        time.sleep(int(globalVars['SleepBetweenTest']))

    print("\n\n")

    print("SUMMARY".center(40, '#'))
    for currTest in testInfo:
        print("Test {} -- {} Result: {}".format(currTest,testInfo[currTest]['Test'], testInfo[currTest]['status']))
        print(testInfo[currTest]['msg'] + "\n")

    sys.exit()

def runTest(globalVars,testToRun,testId):
    testInfo = {**globalVars, **testToRun}
    retDic = {}
    testToRun['status'] = 'PASS'
    testToRun['msg'] = ''
    print("Starting Test" + testId.center(40, '#'))
    for key,value in testInfo.items():
        print("{}: {}".format(key,value))
    # Taking out the file extenstions .bpt
    testInfo['Test Name'] = testInfo['Test']
    testInfo['Test'] += '.bpt'
    testInfo['Network Neighborhood Name'] = testInfo['Network Neighborhood']
    testInfo['Network Neighborhood'] += '.bpt'
    ########################################
    print("Init Phase -- Logging in to {} as user {}".format(testInfo['Chassis Ip'],testInfo['User']))
    bps_session = BPS(testInfo['Chassis Ip'], testInfo['User'], testInfo['Password'])
    bps_session.login()
    ########################################

    if eval(testInfo['Import Test']):
        print("Init Phase -- Import test from local directory")
        status = bps_session.testmodel.importModel(testInfo['Test Name'], testInfo['Test'], True)
        print("Status: {}".format(status.decode()))
    else:
        print("Init Phase -- Assuming test {} already on BPS".format(testInfo['Test']))

    print("Init Phase -- Load a test model")
    pp(bps_session.testmodel.load(template=testInfo['Test Name']))

    name = bps_session.testmodel.name.get()
    print("Init Phase -- Test Name: {}".format(name.decode()))

    ########################################
    if eval(testInfo['Import Neighborhood']):
        print("Init Phase -- Import a Network Neighborhood")
        status = bps_session.network.importNetwork(testInfo['Network Neighborhood Name'], testInfo['Network Neighborhood'], True)
        print("Status: {}".format(status.decode()))
    else:
        print("Init Phase -- Assuming network neighborhood {} already on BPS".format(testInfo['Network Neighborhood Name']))

    print("Init Phase -- Search for the imported network config.")
    nn_list = bps_session.network.search(searchString=testInfo['Network Neighborhood Name'], limit=10, sort="name", sortorder="ascending", clazz="", offset=0, userid=testInfo['User'])
    pp(nn_list)

    print("Init Phase -- Load the network config.")
    bps_session.network.load(template=testInfo['Network Neighborhood Name'])

    name = bps_session.network.name.get()
    print("Init Phase -- Network Name: {}".format(name.decode()))

    network_model = bps_session.network.networkModel.get()

    print("Init Phase -- The Network Elements used in config are:")
    elements = [k for k,v in network_model.items() if v != None]
    print("  %s" % elements)

    #print("Init Phase -- Change mac address on Interfaces")
    #bps_session.network.networkModel.interface["Port 1 - Clients"].set({"duplicate_mac_address": False})
    #bps_session.network.networkModel.interface["Interface 1"].set({"mac_address": "00:CA:FF:EE:00:00"})
    #print("Interface2 mac address set to {}".format(bps_session.network.networkModel.interface["Interface 2"].mac_address.get()))

#    newName = testInfo['Network Neighborhood Name'] + '_' + time.strftime("%Y%m%d-%H%M%S")
    newName = testInfo['Network Neighborhood Name'] + '_' + 'runAndVerifyVersion'
    print("Init Phase -- Save changes made into the network neighborhood as {}".format(newName))
    bps_session.network.saveAs(name=newName, force=True)

    ########################################
    print("Init Phase -- Get the name of the network from the imported test model")
    nn_name = bps_session.testmodel.network.get()
    print("Init Phase -- Network Name: {}".format(nn_name))

    print("Init Phase -- Set the network to {}.".format(newName))
    bps_session.testmodel.network.set(newName)

    #newTestName = testInfo['Test Name'] + '_' + time.strftime("%Y%m%d-%H%M%S")
    newTestName = testInfo['Test Name'] + '_' + 'runAndVerifyVersion'
    print("Init Phase -- Save test as {}".format(newTestName))
    bps_session.testmodel.saveAs(name=newTestName, force=True)

    ########################################
    print("Init Phase -- Reserve Ports")
    for p in json.loads(testInfo['Port List']):
        bps_session.topology.reserve([{'slot': int(testInfo['Slot Number']), 'port': int(p), 'group': 1}])
    ########################################

    print("\nTest Phase -- Run test and wait for it to finish")
    test_id_json = bps_session.testmodel.run(modelname=newTestName, group=1)
    run_id = test_id_json["runid"]
    print("Test Phase -- Test Running under test id: {}".format(run_id))

    testStillRunning = True
    noProgress = 2
    while testStillRunning:
        tempStats = bps_session.testmodel.realTimeStats(int(run_id), "summary", -1)
        prevProgress = -1
        if not tempStats:
            print("Test Phase -- Test id {} did not start, waiting 2 seconds".format(run_id))
            time.sleep(2)
            continue
        if tempStats['progress'] == 100:
            print("Test Phase -- Test id {} finished\n".format(run_id))
            testStillRunning = False
        elif tempStats['progress'] <= prevProgress:
            print("Test Phase -- WARN: Test is NOT making any progress after 30 seconds -- Stuck at {}".format(str(tempStats['progess'])))
            if noProgress > 0:
                time.sleep(2)
                continue
            else:
                break
            noProgress -= 1
        else:
            prevProgress = tempStats['progress']
            print("\nTest Phase -- Test at " + str(int(tempStats['progress']))  + "% completion")
            print("Time: " + str(tempStats['time']) + " seconds")
            for key, value in tempStats['values'].items():
                print("{}: {}".format(key, value))
            time.sleep(30)

    print("Test Phase -- Waiting 5 seconds before continuing")
    time.sleep(5)
    bps_session.topology.stopRun(run_id)

    # Lets look at the table of contents and get protocol applications
    myProtocolDict =  dict()
    getAllContent =  bps_session.reports.getReportContents(runid=run_id)
    for thisContent in getAllContent:
        x = re.search("protocol=(.*)]", thisContent['Section Name'] )
        if x:
           dictKey = str(x.groups()[0])
           myProtocolDict[dictKey] = dict()
           myProtocolDict[dictKey]['Section ID'] = thisContent['Section ID']

    for protocol, sectIdDic in myProtocolDict.items():
        for thisContent in getAllContent:
            x = re.search(sectIdDic['Section ID']+"\.", thisContent['Section ID'])
            if x:
                myProtocolDict[protocol][thisContent['Section Name']] = thisContent['Section ID']

    myMatchTable = dict()



    # Get All the Checks
    allChecks = {}
    testPass = True
    for key in testInfo.keys():
        if re.match(r'Check\d+', key) is not None:
            allChecks[key] = {}
            allChecks[key]['result'] = None
            allChecks[key]['value'] = None
    # Check1: ['7.23.2.1','Receive megabit rate','average','>=','8000']
    for thisCheck in allChecks.keys():
        res = ' , '.join(ast.literal_eval(testInfo[thisCheck]))
        sectionId, tableHeader, whatToTest, operator, passValue = res.split(",")
        if not sectionId.strip()[0].isdigit():
            key,table = sectionId.split(".")
            sectionId = myProtocolDict[key.strip()][table.strip()]
        tabledata = bps_session.reports.getReportTable(runid=run_id, sectionId=sectionId)
        whatToTest = whatToTest.strip()
        if 'match' in whatToTest:
            matchId = whatToTest.split(".", 1)[1]
            rowDict = dict()
            for column in tabledata:
                rowDict[list(column)[0].strip()] = column[list(column)[0].strip()]
            while rowDict['Match Id']:
                key = rowDict['Match Id'].pop(0)
                myMatchTable[key] = dict()
                myMatchTable[key]['string'] = rowDict['Matching String'].pop(0)
                myMatchTable[key]['count'] = rowDict['Matching Count'].pop(0)
            allChecks[thisCheck]['value'] = myMatchTable[key]['count']
            allChecks[thisCheck]['result'] = eval(str(allChecks[thisCheck]['value']) + operator + passValue)
        else:
            for column in tabledata:
                if list(column)[0].strip() == tableHeader.strip():
                    columToProcess = list(column.values())[0]
                    if whatToTest.strip() == 'average':
                        cleanlist = []
                        for item in columToProcess:
                            cleanlist.append(float(item.strip("~")))
                        # Removing the outliers values
                        arrElem = numpy.array(cleanlist)
                        mean = numpy.mean(arrElem, axis=0)
                        sd = numpy.std(arrElem, axis=0)
                        final_list = [x for x in cleanlist if (x > mean - 2 * sd)]
                        final_list = [x for x in final_list if (x < mean + 2 * sd)]
                        allChecks[thisCheck]['value']  = round(statistics.mean(final_list),2)
                        allChecks[thisCheck]['result'] = eval(str(allChecks[thisCheck]['value']) + operator + passValue)
                    elif whatToTest.strip() == 'max':
                        cleanlist = []
                        for item in columToProcess:
                            cleanlist.append(float(item.strip("~")))
                        arrElem = numpy.array(cleanlist)
                        max = numpy.max(arrElem)
                        allChecks[thisCheck]['value'] = max
                        allChecks[thisCheck]['result'] = eval(str(allChecks[thisCheck]['value']) + operator + passValue)
                    elif whatToTest.strip() == 'min':
                        cleanlist = []
                        for item in columToProcess:
                            cleanlist.append(float(item.strip("~")))
                        arrElem = numpy.array(cleanlist)
                        minNumber = numpy.min(arrElem)
                        allChecks[thisCheck]['value'] = minNumber
                        allChecks[thisCheck]['result'] = eval(str(allChecks[thisCheck]['value']) + operator + passValue)



    print("Test Phase -- Test Results:".center(40, '#'))
    for thisCheck in allChecks.keys():
        res = ' , '.join(ast.literal_eval(testInfo[thisCheck]))
        sectionId, tableHeader, whatToTest, operator, passValue = res.split(",")
        if sectionId.strip()[0].isdigit():
            justAString = thisCheck + " - Verify if {} of {}: {} {} {} --  {}".format(whatToTest,
                                                                             tableHeader,
                                                                             allChecks[thisCheck]['value'],
                                                                             operator,
                                                                             passValue,
                                                                             allChecks[thisCheck]['result'])
        else:
            justAString = thisCheck + " - Verify if {} of {} in app {}: {} {} {} --  {}".format(whatToTest,
                                                                             tableHeader,
                                                                             sectionId,
                                                                             allChecks[thisCheck]['value'],
                                                                             operator,
                                                                             passValue,
                                                                             allChecks[thisCheck]['result'])
        print(justAString)

        testToRun['msg'] = testToRun['msg'] + justAString + "\n"

        if not allChecks[thisCheck]['result']:
            testPass = False
            testToRun['status'] = 'FAILED'
    print(("Test Phase -- Overall Test Results: " + testToRun['status'] + "!!!!  ").center(40, '-'))

    ########################################
    print("\nCleanup Phase -- Unreserve ports")
    for p in json.loads(testInfo['Port List']):
        bps_session.topology.unreserve([{'slot': int(testInfo['Slot Number']), 'port': int(p), 'group': 1}])
    ########################################
    print("Cleanup Phase -- Session logout")
    bps_session.logout()

if __name__=='__main__':
    main()

